# Figure A1 — review draft

**Exploratory structural controls and history readout.** (A) Choice accuracy at update 300 on original and freshly sampled test trials; reset results use the fresh bank. (B) Pooled history decoding at update 300 with intact and reset histories. (C, D) Pooled and separately fitted position-specific history decoders at updates 150 and 300. Rows show individual seeds (11, 22, 33) within each variant. Chance is 50%; heatmap values are rounded to integer percentages. All variants retain the predictive recurrent state. Fixed gates sets all three gates to one; No assoc. memory disables the online associative matrix; Both removed combines these interventions. Reset clears all recurrent states, and intact/reset probes are fitted separately. Update 300 decoding and position-specific diagnostics are post hoc; no inferential tests are shown. Position-specific probes are trained and tested within each position, not across held-out positions. Pooled probes use class-balanced sampling, whereas position-specific probes use the available within-position samples; differences cannot be attributed solely to representational geometry.

## Methods notes to retain beside the appendix

Each behavior bank contains 256 trials and 768 scored choices. Pooled probe test banks contain 4,608 corridor samples from 256 trials; position-specific test banks contain 768 samples per position. Within-trial samples are not independent experimental replicates. The figure shows all three development seeds; uncertainty is represented by the individual observations rather than a fitted confidence interval. Pooled probes use the original class-balanced sampling procedure; position-specific probes use the available samples in each position. Differences therefore cannot be attributed solely to representational geometry. Position-specific probes are trained and tested within position and do not test cross-position transfer. Fresh trials come from the same task generator. Corridor decoding and behavioral choices occur at different task locations, so their discrepancy alone does not identify a causal readout bottleneck.

## 中文评判说明

- A：300 更新的行为，保留原测试、新同分布测试以及新测试上的历史重置结果。点在行内略作纵向错开，以免接近值互相遮挡。
- B：300 更新的合并历史解码与重置对照，同一行的配对连线便于比较。
- C、D：原先指定的 150 更新表征端点和事后增加的 300 更新端点；左列为合并探针，其余六列为分别拟合的位置探针。
- 所有四组、三个种子全部保留，无显著性星号，无选择性隐藏反例。图中整数仅用于显示，完整精度存于 plotted_data.csv。
- No assoc. memory 特指去除在线关联记忆矩阵，不表示去除了全部记忆；Both removed 仍保留预测循环状态。正文和图注须保留这一限定。
- 这张图适合支持“合并可读性、条件可读性、行为使用应区分”，不支持模块必要性、跨位置迁移或唯一生物机制。

## Delivery and QA

Review draft only; not inserted into Overleaf. Size: 178 × 190 mm. Font minimum: 8 pt. Vector PDF/SVG and 220 dpi PNG retained, together with reproducible Python source and extracted full-precision CSV. Color and grayscale final-size previews were visually inspected; no text extends beyond the canvas. No new training or probe fitting was performed.


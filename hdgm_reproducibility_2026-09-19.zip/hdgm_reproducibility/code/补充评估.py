"""Evaluate frozen pilot checkpoints. No core training; probes alone are fitted."""
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
import torch
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pilot_frozen',ROOT/'分析_三种子原版.py')
a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
b=a.b

@torch.no_grad()
def behavior(model,bank,reset):
    model.eval(); counts={}
    for raw in bank:
        batch=b.to_device(raw)
        out=model(batch['x'],batch['action'],reset_mask=batch['reset_mask'] if reset else None)
        pred=out['choice_logits'].argmax(-1); y=batch['branch'][:,:-1]
        for trip in range(1,model.core.cfg.trips_per_trial):
            mask=batch['choice_mask'][:,:-1] & (batch['trip'][:,:-1]==trip)
            row=counts.setdefault(str(trip),[0,0]);row[0]+=int(((pred==y)&mask).sum());row[1]+=int(mask.sum())
    return {'accuracy':sum(x[0] for x in counts.values())/sum(x[1] for x in counts.values()),'by_trip':{k:{'correct':v[0],'total':v[1],'accuracy':v[0]/v[1]} for k,v in counts.items()}}

def decode(data,cfg,seed,field='X',subset=None):
    ds={}
    for split,d in data.items():
        mask=np.ones(len(d['y']),dtype=bool) if subset is None else d[subset[0]]==subset[1]
        x=b.timing_features(d,cfg) if field=='timing' else d[field]
        ds[split]=(x[mask],d['y'][mask])
    if any(len(np.unique(y))<2 for x,y in ds.values()):return {'status':'insufficient_classes'}
    xs=b.standardize(*(ds[k][0] for k in ['train','val','test']))
    ts=[torch.as_tensor(x,dtype=torch.float32,device=b.DEVICE) for x in xs]
    ys=[torch.as_tensor(ds[k][1],dtype=torch.long,device=b.DEVICE) for k in ['train','val','test']]
    torch.manual_seed(seed);probe=b.LinearProbe(xs[0].shape[1]).to(b.DEVICE)
    opt=torch.optim.Adam(probe.parameters(),lr=cfg.probe_lr,weight_decay=cfg.probe_weight_decay)
    best=-1;stale=0;trace=[]
    for epoch in range(cfg.probe_epochs):
        probe.train();opt.zero_grad();loss=torch.nn.functional.cross_entropy(probe(ts[0]),ys[0]);loss.backward();opt.step()
        probe.eval()
        with torch.no_grad():
            train=float((probe(ts[0]).argmax(1)==ys[0]).float().mean());val=float((probe(ts[1]).argmax(1)==ys[1]).float().mean())
        trace.append({'epoch':epoch+1,'loss':float(loss.detach()),'train':train,'val':val})
        if val>best+1e-8:best=val;state=b.state_dict_cpu(probe);best_epoch=epoch+1;stale=0
        else:stale+=1
        if stale>=cfg.probe_patience:break
    probe.load_state_dict(state)
    with torch.no_grad():test=float((probe(ts[2]).argmax(1)==ys[2]).float().mean())
    return {'test_accuracy':test,'best_epoch':best_epoch,'trace':trace,'counts':{k:len(v[1]) for k,v in ds.items()}}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--debug',action='store_true');args=parser.parse_args()
    torch.set_num_threads(4)
    src=ROOT/'factorial_3seed_outputs';protocol=json.loads((src/'protocol.json').read_text(encoding='utf8'))
    for name,file in [('分析.py','分析_三种子原版.py'),('分叉.py','分叉.py')]:
        assert hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==protocol['source_sha256'][name], 'Frozen source mismatch'
    cfg=b.SplitterV7Config(**protocol['config'])
    dest=ROOT/('checkpoint_diagnostics_debug' if args.debug else 'checkpoint_diagnostics_v1');dest.mkdir(exist_ok=True)
    manifest={'debug':args.debug,'source_protocol':protocol,'diagnostic_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'endpoints':[150,300],'scope':'Post-hoc exploratory frozen-checkpoint evaluation; fresh evaluation bank is not external generalization; reset clears g,M,v; independently fitted probes; stratified probes use all observations without class resampling.'}
    mp=dest/'protocol.json'
    if mp.exists():assert json.loads(mp.read_text(encoding='utf8'))==manifest,'Diagnostic protocol changed; preserve old output and choose a new version directory'
    a.save_json(mp,manifest)
    records=[]
    for seed in ([33] if args.debug else protocol['seeds']):
        env=b.CounterbalancedBifurcationEnv(cfg,seed+17);banks=b.make_banks(env,cfg,seed)
        fresh=b.build_bank(env.clone(seed+808080),1 if args.debug else cfg.test_batches,2 if args.debug else cfg.bank_batch_size)
        if args.debug:
            banks={k:[{n:t[:2] for n,t in v[0].items()}] for k,v in banks.items()}
            cfg.probe_epochs=2;cfg.probe_patience=2
        for name,memory,gates in a.VARIANTS:
            for endpoint in [150,300]:
                outpath=dest/f'seed_{seed}_{name}_{endpoint}.json'
                if outpath.exists():records.append(json.loads(outpath.read_text(encoding='utf8')));continue
                cp=src/f'seed_{seed}'/(f'{name}_representation.pt' if endpoint==150 else f'{name}_latest.pt')
                saved=torch.load(cp,map_location='cpu',weights_only=False)
                if endpoint==300:assert saved['update']==300
                model=b.SequenceChoiceModel(a.FactorialCore(cfg,memory,gates),cfg.hidden_dim).to(b.DEVICE)
                model.load_state_dict(saved if endpoint==150 else saved['model']);model.eval()
                before=b.state_dict_cpu(model)
                result={'seed':seed,'variant':name,'endpoint':endpoint,'checkpoint_sha256':hashlib.sha256(cp.read_bytes()).hexdigest(),'conditions':{}}
                for reset in [False,True]:
                    data={s:b.collect_alias_dataset(model,banks['probe_'+s],'mem',reset) for s in ['train','val','test']}
                    cond={'behavior_original':behavior(model,banks['test'],reset),'behavior_fresh':behavior(model,fresh,reset),'geometry':b.geometry_metrics(data['test'])}
                    # Preserve the original probe implementation for primary endpoint comparability.
                    cond['history_decode']=b.fit_probe(data['train']['X'],data['train']['y'],data['val']['X'],data['val']['y'],data['test']['X'],data['test']['y'],cfg,9000+seed)
                    cond['probe_diagnostic']=decode(data,cfg,9000+seed)
                    cond['by_position']={str(p):decode(data,cfg,9000+seed,subset=('pos',p)) for p in sorted(np.unique(data['test']['pos']).tolist())}
                    cond['by_trip']={str(t):decode(data,cfg,9000+seed,subset=('trip',t)) for t in sorted(np.unique(data['test']['trip']).tolist())}
                    cond['observation_decode']=decode(data,cfg,9000+seed,field='obs')
                    cond['timing_decode']=decode(data,cfg,9000+seed,field='timing')
                    result['conditions']['reset' if reset else 'full']=cond
                assert all(torch.equal(v,model.state_dict()[k].cpu()) for k,v in before.items()),'Core checkpoint changed'
                result['checkpoint_unchanged']=True
                a.save_json(outpath,result);records.append(result)
                print(f'SAVED seed={seed} {name} update={endpoint}',flush=True)
                del model;torch.cuda.empty_cache()
    a.save_json(dest/'summary.json',{'debug':args.debug,'records':records});print('COMPLETE',flush=True)
if __name__=='__main__':main()

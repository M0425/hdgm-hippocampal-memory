# Figure 5 — layout revision 2

This revision retains the data and statistical definitions documented in
figure5_integrated_BC_caption.md, with the following changes to presentation.

- A expands from 8/24 to 9/24 of the top-row layout grid (approximately 12.5%
  wider). Native vector house/tree cue cards and a noisy-house cue illustrate
  aliasing versus observation noise. These are conceptual symbols, not the
  actual experimental stimulus set. The population glyphs and frozen
  EC–CA3–CA1 computational route remain conceptual.
- B takes the remaining 15/24 of the top-row grid. Its plotting and marginal
  axes use more of the available panel width, reducing the unused right margin.
  Axis limits, observations, means, glyph encodings and uncertainty definitions
  remain unchanged.
- C/D/E/F retain the previous plotting calculations and layout. C's 24 means
  and 48 confidence-interval endpoints still match the accepted CSV exactly.
- Previous complete-figure exports remain available without being overwritten.
- Color and grayscale renders have been inspected after the last revision.
- Master size is 431.8 × 368.3 mm, not a journal-column-size submission claim.

Use rebuild_figure5_integrated.py together with figure5_panel_a_cartoon.py and
the earlier B/C sources to reproduce this revision.

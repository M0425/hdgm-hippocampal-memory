import json,hashlib,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];p=ROOT/'pilot';d=p/'checkpoint_diagnostics_v1'
s=json.loads((d/'summary.json').read_text(encoding='utf8'));proto=json.loads((d/'protocol.json').read_text(encoding='utf8'))
assert not s['debug'] and not proto['debug']
assert len(s['records'])==24
seen=set();rows=[]
for r in s['records']:
 key=(r['seed'],r['variant'],r['endpoint']);assert key not in seen;seen.add(key)
 assert r['checkpoint_unchanged']
 assert r==json.loads((d/f"seed_{key[0]}_{key[1]}_{key[2]}.json").read_text(encoding='utf8'))
 cp=p/'factorial_3seed_outputs'/f'seed_{key[0]}'/(f'{key[1]}_representation.pt' if key[2]==150 else f'{key[1]}_latest.pt')
 assert hashlib.sha256(cp.read_bytes()).hexdigest()==r['checkpoint_sha256']
 row={'key':key}
 for name,c in r['conditions'].items():
  row[name]={'decode':round(c['history_decode'],4),'behavior':round(c['behavior_original']['accuracy'],4),'fresh':round(c['behavior_fresh']['accuracy'],4),'trip':[round(v['accuracy'],4) for v in c['behavior_original']['by_trip'].values()],'probe':round(c['probe_diagnostic']['test_accuracy'],4),'position':[round(v['test_accuracy'],3) for v in c['by_position'].values()],'trip_decode':[round(v['test_accuracy'],3) for v in c['by_trip'].values()]}
 rows.append(row)
assert seen=={(seed,v,e) for seed in [11,22,33] for v in ['full','fixed_gates','no_memory','neither'] for e in [150,300]}

manifest=json.loads((ROOT/"MANIFEST.json").read_text(encoding="utf8"))
for entry in manifest:
 assert hashlib.sha256((ROOT/entry["file"]).read_bytes()).hexdigest()==entry["sha256"], entry["file"]
print(f"PASS: {len(manifest)} file hashes; all 24 pilot records, endpoints and checkpoint hashes.")
